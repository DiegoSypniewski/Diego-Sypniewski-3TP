import csv

class Ksiazka:
    def __init__(self, tytul, autor, rok, dostepna=True):
        self.tytul = tytul
        self.autor = autor
        self.rok = rok
        self.dostepna = dostepna

    def __str__(self):
        status = "Dostępna" if self.dostepna else "Wypożyczona"
        return f"{self.tytul} ({self.rok}), {self.autor}, Status: {status}"

    def do_slownika(self):
        return {
            "Tytuł": self.tytul,
            "Autor": self.autor,
            "Rok": self.rok,
            "Dostępna": str(self.dostepna)
        }

    @staticmethod
    def z_slownika(slownik):
        return Ksiazka(
            slownik["Tytuł"],
            slownik["Autor"],
            int(slownik["Rok"]),
            slownik["Dostępna"].lower() == 'true'
        )


class Biblioteka:
    def __init__(self):
        self.ksiazki = []

    def dodaj_ksiazke(self, ksiazka):
        self.ksiazki.append(ksiazka)
        print("Dodano książkę!")

    def wypozycz_ksiazke(self, tytul):
        znalezione = list(filter(lambda k: k.tytul.lower() == tytul.lower(), self.ksiazki))
        if not znalezione:
            print("Nie znaleziono książki.")
            return
        for ks in znalezione:
            if ks.dostepna:
                ks.dostepna = False
                print(f"Wypożyczono: {ks.tytul}")
                return
        print("Książka jest niedostępna.")

    def zwroc_ksiazke(self, tytul):
        znalezione = list(filter(lambda k: k.tytul.lower() == tytul.lower(), self.ksiazki))
        if not znalezione:
            print("Nie znaleziono książki.")
            return
        for ks in znalezione:
            if not ks.dostepna:
                ks.dostepna = True
                print(f"Oddano: {ks.tytul}")
                return
        print("Książka była już dostępna.")

    def pokaz_dostepne(self):
        dostepne = list(filter(lambda k: k.dostepna, self.ksiazki))
        if dostepne:
            print("\n--- Dostępne książki ---")
            for ks in dostepne:
                print(ks)
        else:
            print("Brak dostępnych książek.")

    def zapisz_do_csv(self, nazwa_pliku):
        try:
            with open(nazwa_pliku, mode='w', newline='', encoding='utf-8') as plik:
                naglowki = ["Tytuł", "Autor", "Rok", "Dostępna"]
                writer = csv.DictWriter(plik, fieldnames=naglowki)
                writer.writeheader()
                for ks in self.ksiazki:
                    writer.writerow(ks.do_slownika())
            print("Zapisano dane do pliku.")
        except Exception as e:
            print(f"Błąd podczas zapisu do pliku: {e}")

    def wczytaj_z_csv(self, nazwa_pliku):
        try:
            with open(nazwa_pliku, mode='r', encoding='utf-8') as plik:
                reader = csv.DictReader(plik)
                self.ksiazki = [Ksiazka.z_slownika(wiersz) for wiersz in reader]
            print("Wczytano dane z pliku.")
        except FileNotFoundError:
            print("Plik nie istnieje.")
        except Exception as e:
            print(f"Błąd podczas odczytu pliku: {e}")


def menu():
    biblioteka = Biblioteka()

    while True:
        print("\nSystem Zarządzania Biblioteką")
        print("1. Dodaj książkę")
        print("2. Wypożycz książkę")
        print("3. Zwróć książkę")
        print("4. Pokaż dostępne książki")
        print("5. Zapisz do pliku CSV")
        print("6. Wczytaj z pliku CSV")
        print("0. Wyjdź")

        wybor = input("Wybierz opcję: ")

        if wybor == "1":
            tytul = input("Podaj tytuł: ")
            autor = input("Podaj autora: ")
            try:
                rok = int(input("Podaj rok: "))
                biblioteka.dodaj_ksiazke(Ksiazka(tytul, autor, rok))
            except ValueError:
                print("Rok musi być liczbą.")

        elif wybor == "2":
            tytul = input("Podaj tytuł książki do wypożyczenia: ")
            biblioteka.wypozycz_ksiazke(tytul)

        elif wybor == "3":
            tytul = input("Podaj tytuł książki do zwrotu: ")
            biblioteka.zwroc_ksiazke(tytul)

        elif wybor == "4":
            biblioteka.pokaz_dostepne()

        elif wybor == "5":
            nazwa_pliku = input("Podaj nazwę pliku CSV do zapisu: ")
            biblioteka.zapisz_do_csv(nazwa_pliku)

        elif wybor == "6":
            nazwa_pliku = input("Podaj nazwę pliku CSV do odczytu: ")
            biblioteka.wczytaj_z_csv(nazwa_pliku)

        elif wybor == "0":
            break

        else:
            print("Nieprawidłowy wybór. Spróbuj ponownie.")


if __name__ == "__main__":
    menu()